﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Media3D;
using Rubik_s_Cube.Models;

namespace Rubik_s_Cube
{
    public partial class MainWindow : Window
    {
        private readonly RubiksCube _cube = new RubiksCube();
        private readonly Model3DGroup[,,] _cubies = new Model3DGroup[3, 3, 3];
        private readonly Transform3DGroup _scene = new Transform3DGroup();
        private Point _lastMouse;
        private bool _dragging;
        private bool _isAnimating; // Flag to prevent moves during animation
        private readonly Queue<string> _moveQueue = new Queue<string>();
        private Dictionary<char, char> _orientationMap;
        private enum CubePerspective { Green, Blue, Red, Orange, White, Yellow }
        private CubePerspective _currentPerspective = CubePerspective.Green;

        public MainWindow()
        {
            InitializeComponent();
            BuildCube();
            UpdateCubeVisuals();
            // Snap to the initial perspective without animation on startup
            SnapToCurrentPerspective();
            MoveInput.Focus();
        }

        #region Cube Construction and Visuals
        private void BuildCube()
        {
            var root = new Model3DGroup();
            root.Children.Add(new AmbientLight(Color.FromRgb(120, 120, 120)));
            root.Children.Add(new DirectionalLight(Color.FromRgb(80, 80, 80), new Vector3D(-1, -1, -2)));

            const double size = 1.0, gap = 0.15;
            double pitch = size + gap;

            for (int x = 0; x < 3; x++)
                for (int y = 0; y < 3; y++)
                    for (int z = 0; z < 3; z++)
                    {
                        if (x == 1 && y == 1 && z == 1) continue;

                        var cubie = CreateCubie(size);
                        cubie.Transform = new TranslateTransform3D(
                            (x - 1) * pitch, (y - 1) * pitch, (z - 1) * pitch);
                        root.Children.Add(cubie);
                        _cubies[x, y, z] = cubie;
                    }

            var rootVisual = new ModelVisual3D { Content = root, Transform = _scene };
            MyViewport.Children.Add(rootVisual);
            _scene.Children.Add(new MatrixTransform3D(Matrix3D.Identity));
        }

        private Model3DGroup CreateCubie(double size)
        {
            var mg = new Model3DGroup();
            var plastic = new DiffuseMaterial(new SolidColorBrush(Color.FromRgb(40, 40, 40)));
            var bodyMaterial = new MaterialGroup { Children = { plastic } };

            const double bevelDistance = 0.12;
            var body = new GeometryModel3D(CreateBeveledBox(size, bevelDistance), bodyMaterial)
            {
                BackMaterial = bodyMaterial
            };
            mg.Children.Add(body);

            double s = size * 0.9;
            double offset = size / 2;

            var stickerColors = new[]
            {
                new SolidColorBrush(Color.FromRgb(0, 80, 150)),   // Softer Blue
                new SolidColorBrush(Color.FromRgb(0, 155, 80)),   // Softer Green
                new SolidColorBrush(Color.FromRgb(220, 220, 220)), // Softer White (Light Gray)
                new SolidColorBrush(Color.FromRgb(255, 210, 0)),  // Softer Yellow
                new SolidColorBrush(Color.FromRgb(190, 40, 40)),   // Softer Red
                new SolidColorBrush(Color.FromRgb(255, 140, 0))   // Softer Orange
            };

            for (int i = 0; i < 6; i++)
            {
                var mesh = new MeshGeometry3D
                {
                    Positions = new Point3DCollection(new[]
                    {
                        new Point3D(-s / 2, -s / 2, 0), new Point3D(s / 2, -s / 2, 0),
                        new Point3D(s / 2, s / 2, 0), new Point3D(-s / 2, s / 2, 0)
                    }),
                    TriangleIndices = new Int32Collection { 0, 1, 2, 0, 2, 3 }
                };

                var mat = new MaterialGroup { Children = { new DiffuseMaterial(stickerColors[i]) } };
                var face = new GeometryModel3D(mesh, mat)
                {
                    BackMaterial = mat,
                    Transform = GetStickerXForm(i, offset)
                };
                mg.Children.Add(face);
            }
            return mg;
        }

        private Transform3D GetStickerXForm(int f, double o)
        {
            var tg = new Transform3DGroup();
            double stickerOffset = o + 0.01;
            switch (f)
            {
                case 0: tg.Children.Add(new RotateTransform3D(new AxisAngleRotation3D(new Vector3D(0, 1, 0), 180))); tg.Children.Add(new TranslateTransform3D(0, 0, -stickerOffset)); break;
                case 1: tg.Children.Add(new TranslateTransform3D(0, 0, +stickerOffset)); break;
                case 2: tg.Children.Add(new RotateTransform3D(new AxisAngleRotation3D(new Vector3D(1, 0, 0), -90))); tg.Children.Add(new TranslateTransform3D(0, +stickerOffset, 0)); break;
                case 3: tg.Children.Add(new RotateTransform3D(new AxisAngleRotation3D(new Vector3D(1, 0, 0), +90))); tg.Children.Add(new TranslateTransform3D(0, -stickerOffset, 0)); break;
                case 4: tg.Children.Add(new RotateTransform3D(new AxisAngleRotation3D(new Vector3D(0, 1, 0), +90))); tg.Children.Add(new TranslateTransform3D(+stickerOffset, 0, 0)); break;
                case 5: tg.Children.Add(new RotateTransform3D(new AxisAngleRotation3D(new Vector3D(0, 1, 0), -90))); tg.Children.Add(new TranslateTransform3D(-stickerOffset, 0, 0)); break;
            }
            return tg;
        }

        private MeshGeometry3D CreateBeveledBox(double size, double bevelDistance)
        {
            var mesh = new MeshGeometry3D();
            double s = size / 2.0;
            double b = bevelDistance;

            var points = new Point3D[]
            {
                new Point3D(s - b, s, b - s), new Point3D(b - s, s, b - s), new Point3D(b - s, s, s - b), new Point3D(s - b, s, s - b),
                new Point3D(s - b, -s, b - s), new Point3D(b - s, -s, b - s), new Point3D(b - s, -s, s - b), new Point3D(s - b, -s, s - b),
                new Point3D(s, s - b, b - s), new Point3D(s, b - s, b - s), new Point3D(s, b - s, s - b), new Point3D(s, s - b, s - b),
                new Point3D(-s, s - b, b - s), new Point3D(-s, b - s, b - s), new Point3D(-s, b - s, s - b), new Point3D(-s, s - b, s - b),
                new Point3D(s - b, s - b, s), new Point3D(b - s, s - b, s), new Point3D(b - s, b - s, s), new Point3D(s - b, b - s, s),
                new Point3D(s - b, s - b, -s), new Point3D(b - s, s - b, -s), new Point3D(b - s, b - s, -s), new Point3D(s - b, b - s, -s),
            };
            mesh.Positions = new Point3DCollection(points);

            var indices = new Int32[]
            {
                1, 0, 3, 1, 3, 2, 4, 5, 6, 4, 6, 7, 8, 9, 10, 8, 10, 11, 14, 13, 12, 14, 12, 15, 19, 18, 17, 19, 17, 16, 20, 21, 22, 20, 22, 23, 3, 16, 17, 3, 17, 2, 20, 0, 1, 20, 1, 21, 0, 8, 11, 0, 11, 3, 2, 15, 12, 2, 12, 1, 18, 19, 7, 18, 7, 6, 5, 4, 23, 5, 23, 22, 9, 4, 7, 9, 7, 10, 13, 14, 6, 13, 6, 5, 11, 10, 19, 11, 19, 16, 15, 17, 18, 15, 18, 14, 8, 20, 23, 8, 23, 9, 12, 13, 22, 12, 22, 21, 3, 11, 16, 2, 17, 15, 0, 20, 8, 1, 12, 21, 10, 7, 19, 14, 18, 6, 9, 23, 4, 13, 5, 22,
            };
            mesh.TriangleIndices = new Int32Collection(indices);
            return mesh;
        }

        private void UpdateCubeVisuals()
        {
            RebuildCubieTransforms();
            for (int xi = 0; xi < 3; xi++)
                for (int yi = 0; yi < 3; yi++)
                    for (int zi = 0; zi < 3; zi++)
                    {
                        if (_cubies[xi, yi, zi] == null) continue;
                        var cubie = _cubies[xi, yi, zi];
                        int x = xi - 1, y = yi - 1, z = zi - 1;
                        for (int f = 0; f < 6; f++)
                        {
                            var face = (GeometryModel3D)cubie.Children[f + 1];
                            string? code = f switch
                            {
                                0 when z == -1 => _cube.B[1 - y, 1 - x],
                                1 when z == +1 => _cube.F[1 - y, x + 1],
                                2 when y == +1 => _cube.U[z + 1, x + 1],
                                3 when y == -1 => _cube.D[1 - z, x + 1],
                                4 when x == +1 => _cube.R[1 - y, 1 - z],
                                5 when x == -1 => _cube.L[1 - y, z + 1],
                                _ => null
                            };
                            Brush b = code switch
                            {
                                "W" => new SolidColorBrush(Color.FromRgb(220, 220, 220)),
                                "Y" => new SolidColorBrush(Color.FromRgb(255, 210, 0)),
                                "G" => new SolidColorBrush(Color.FromRgb(0, 155, 80)),
                                "B" => new SolidColorBrush(Color.FromRgb(0, 80, 150)),
                                "R" => new SolidColorBrush(Color.FromRgb(190, 40, 40)),
                                "O" => new SolidColorBrush(Color.FromRgb(255, 140, 0)),
                                _ => Brushes.Transparent
                            };
                            if (face.Material is MaterialGroup matGroup && matGroup.Children.Count > 0 && matGroup.Children[0] is DiffuseMaterial diffuse)
                            {
                                diffuse.Brush = b;
                            }
                        }
                    }
        }
        #endregion

        #region Input and Move Handling
        private void MoveInput_KeyDown(object s, KeyEventArgs e)
        {
            if (e.Key != Key.Enter) return;
            string move = MoveInput.Text.Trim().ToUpper();
            if (string.IsNullOrEmpty(move)) return;
            AnimateSingleMove(GetMappedMove(move));
            MoveInput.Clear();
        }

        private void MoveButton_Click(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button b)) return;
            string move = b.Content.ToString();
            AnimateSingleMove(GetMappedMove(move));
        }

        private void AnimateSingleMove(string move)
        {
            if (_isAnimating) return;
            _isAnimating = true;
            AnimateMove(move, () => { _isAnimating = false; });
        }

        private void AnimateMove(string move, Action onCompleted)
        {
            char face = move[0];
            double angle = move.Contains("'") ? -90 : (move.Contains("2") ? 180 : 90);

            var cubiesToAnimate = new List<Model3DGroup>();
            int sliceIndex;

            switch (face)
            {
                case 'R': case 'U': case 'F': sliceIndex = 2; break;
                case 'L': case 'D': case 'B': sliceIndex = 0; break;
                default: sliceIndex = 1; break; // M, E, S moves
            }

            Vector3D axis = new Vector3D();
            switch (face)
            {
                case 'R': axis = new Vector3D(-1, 0, 0); for (int y = 0; y < 3; y++) for (int z = 0; z < 3; z++) cubiesToAnimate.Add(_cubies[sliceIndex, y, z]); break;
                case 'L': axis = new Vector3D(1, 0, 0); for (int y = 0; y < 3; y++) for (int z = 0; z < 3; z++) cubiesToAnimate.Add(_cubies[sliceIndex, y, z]); break;
                case 'U': axis = new Vector3D(0, -1, 0); for (int x = 0; x < 3; x++) for (int z = 0; z < 3; z++) cubiesToAnimate.Add(_cubies[x, sliceIndex, z]); break;
                case 'D': axis = new Vector3D(0, 1, 0); for (int x = 0; x < 3; x++) for (int z = 0; z < 3; z++) cubiesToAnimate.Add(_cubies[x, sliceIndex, z]); break;
                case 'F': axis = new Vector3D(0, 0, -1); for (int x = 0; x < 3; x++) for (int y = 0; y < 3; y++) cubiesToAnimate.Add(_cubies[x, y, sliceIndex]); break;
                case 'B': axis = new Vector3D(0, 0, 1); for (int x = 0; x < 3; x++) for (int y = 0; y < 3; y++) cubiesToAnimate.Add(_cubies[x, y, sliceIndex]); break;
                default:
                    onCompleted?.Invoke();
                    return;
            }

            var rotation = new AxisAngleRotation3D(axis, 0);
            var rotateTransform = new RotateTransform3D(rotation);

            foreach (var cubie in cubiesToAnimate)
            {
                if (cubie == null) continue;
                var transformGroup = new Transform3DGroup();
                transformGroup.Children.Add(cubie.Transform);
                transformGroup.Children.Add(rotateTransform);
                cubie.Transform = transformGroup;
            }

            var animation = new DoubleAnimation(0, angle, new Duration(TimeSpan.FromMilliseconds(250)))
            {
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
            };
            animation.Completed += (s, e) =>
            {
                PerformMove(move);
                onCompleted?.Invoke();
            };

            rotation.BeginAnimation(AxisAngleRotation3D.AngleProperty, animation);
        }

        private void CubeRotationButton_Click(object sender, RoutedEventArgs e)
        {
            if (_isAnimating || !(sender is Button b)) return;
            AnimateWholeCubeRotation(b.Content.ToString());
        }

        private void CubeRollButton_Click(object sender, RoutedEventArgs e)
        {
            if (_isAnimating || !(sender is Button b)) return;
            bool isClockwise = b.Content.ToString() == "CW";
            AnimateCubeRoll(isClockwise);
        }

        private void AnimateWholeCubeRotation(string rotation)
        {
            if (_isAnimating) return;
            _isAnimating = true;

            UpdateOrientationMap(rotation);
            var axis = new Vector3D();
            double angle = rotation.Contains("'") ? -90 : (rotation.Contains("2") ? 180 : 90);
            switch (rotation[0])
            {
                case 'x': axis = new Vector3D(1, 0, 0); break;
                case 'y': axis = new Vector3D(0, 1, 0); break;
                case 'z': axis = new Vector3D(0, 0, 1); break;
            }

            var currentTransform = _scene.Children[0].Clone();
            var rotation3D = new AxisAngleRotation3D(axis, 0);
            var rotateTransform3D = new RotateTransform3D(rotation3D);
            var newTransform = new Transform3DGroup();
            newTransform.Children.Add(rotateTransform3D);
            newTransform.Children.Add(currentTransform);
            _scene.Children[0] = newTransform;

            var animation = new DoubleAnimation(0, angle, new Duration(TimeSpan.FromMilliseconds(300)))
            {
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
            };

            animation.Completed += (s, e) =>
            {
                _scene.Children[0] = new MatrixTransform3D(newTransform.Value);
                _isAnimating = false;
            };
            rotation3D.BeginAnimation(AxisAngleRotation3D.AngleProperty, animation);
        }

        private void AnimateCubeRoll(bool isClockwise)
        {
            if (_isAnimating) return;
            _isAnimating = true;
            UpdateOrientationMapForRoll(isClockwise);
            double angle = isClockwise ? 90 : -90;
            var axis = Camera.LookDirection;
            var currentTransform = _scene.Children[0].Clone();
            var rotation3D = new AxisAngleRotation3D(axis, 0);
            var rotateTransform3D = new RotateTransform3D(rotation3D);
            var newTransform = new Transform3DGroup();
            newTransform.Children.Add(rotateTransform3D);
            newTransform.Children.Add(currentTransform);
            _scene.Children[0] = newTransform;
            var animation = new DoubleAnimation(0, angle, new Duration(TimeSpan.FromMilliseconds(300)))
            {
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
            };
            animation.Completed += (s, e) =>
            {
                _scene.Children[0] = new MatrixTransform3D(newTransform.Value);
                _isAnimating = false;
            };
            rotation3D.BeginAnimation(AxisAngleRotation3D.AngleProperty, animation);
        }

        private void ScrambleButton_Click(object sender, RoutedEventArgs e)
        {
            if (_isAnimating) return;

            var moves = new[] { "R", "L", "U", "D", "F", "B" };
            var modifiers = new[] { "", "'", "2" };
            var random = new Random();

            _moveQueue.Clear();
            for (int i = 0; i < 20; i++)
            {
                var move = moves[random.Next(moves.Length)];
                var modifier = modifiers[random.Next(modifiers.Length)];
                _moveQueue.Enqueue(move + modifier);
            }

            if (_moveQueue.Count > 0)
            {
                _isAnimating = true;
                ProcessMoveQueue();
            }
        }

        private void ProcessMoveQueue()
        {
            if (_moveQueue.Count > 0)
            {
                string move = _moveQueue.Dequeue();
                AnimateMove(move, ProcessMoveQueue); // Pass self as callback for sequence
            }
            else
            {
                _isAnimating = false; // End of sequence
            }
        }

        private void PerformMove(string move)
        {
            _cube.PerformMove(move);
            UpdateCubiePositions(move);
            UpdateCubeVisuals();
        }
        #endregion

        #region Logical and Visual Updates
        private void UpdateCubiePositions(string move)
        {
            char face = move[0];
            int turns = move.Contains("'") ? 3 : (move.Contains("2") ? 2 : 1);
            for (int i = 0; i < turns; i++)
            {
                var temp = (Model3DGroup[,,])_cubies.Clone();
                switch (face)
                {
                    case 'R': for (int y = 0; y < 3; y++) for (int z = 0; z < 3; z++) _cubies[2, y, z] = temp[2, 2 - z, y]; break;
                    case 'L': for (int y = 0; y < 3; y++) for (int z = 0; z < 3; z++) _cubies[0, y, z] = temp[0, z, 2 - y]; break;
                    case 'U': for (int x = 0; x < 3; x++) for (int z = 0; z < 3; z++) _cubies[x, 2, z] = temp[2 - z, 2, x]; break;
                    case 'D': for (int x = 0; x < 3; x++) for (int z = 0; z < 3; z++) _cubies[x, 0, z] = temp[z, 0, 2 - x]; break;
                    case 'F': for (int x = 0; x < 3; x++) for (int y = 0; y < 3; y++) _cubies[x, y, 2] = temp[2 - y, x, 2]; break;
                    case 'B': for (int x = 0; x < 3; x++) for (int y = 0; y < 3; y++) _cubies[x, y, 0] = temp[y, 2 - x, 0]; break;
                }
            }
        }

        private void RebuildCubieTransforms()
        {
            const double size = 1.0, gap = 0.15;
            double pitch = size + gap;
            for (int x = 0; x < 3; x++)
                for (int y = 0; y < 3; y++)
                    for (int z = 0; z < 3; z++)
                    {
                        if (_cubies[x, y, z] != null)
                        {
                            _cubies[x, y, z].Transform = new TranslateTransform3D((x - 1) * pitch, (y - 1) * pitch, (z - 1) * pitch);
                        }
                    }
        }
        #endregion

        #region Perspective, Orientation, and Rotation
        private void MyViewport_MouseDown(object s, MouseButtonEventArgs e)
        {
            if (e.LeftButton != MouseButtonState.Pressed || _isAnimating) return;
            _dragging = true;
            _lastMouse = e.GetPosition(this);
            Mouse.Capture(MyViewport);
        }

        private void MyViewport_MouseMove(object s, MouseEventArgs e)
        {
            if (!_dragging) return;
            var currentPosition = e.GetPosition(this);
            var delta = currentPosition - _lastMouse;
            _lastMouse = currentPosition;

            if (!(_scene.Children[0] is MatrixTransform3D matrixTransform)) return;

            Matrix3D matrix = matrixTransform.Matrix;
            Vector3D up = Camera.UpDirection;
            Vector3D right = Vector3D.CrossProduct(Camera.LookDirection, up);

            double scale = 0.5;

            // This version implements an "orbital" or "trackball" rotation.
            // Dragging the mouse appears to move the camera around the cube.
            var yaw = new Quaternion(up, delta.X * scale);
            var pitch = new Quaternion(right, delta.Y * scale);

            matrix.Rotate(pitch * yaw);
            matrixTransform.Matrix = matrix;
        }

        private void MyViewport_MouseUp(object s, MouseButtonEventArgs e)
        {
            _dragging = false;
            Mouse.Capture(null);
        }

        private void SwitchPerspective_Click(object sender, RoutedEventArgs e)
        {
            if (_isAnimating || !(sender is Button b)) return;

            CubePerspective targetPerspective = b.Content.ToString() switch
            {
                "W" => CubePerspective.White,
                "Y" => CubePerspective.Yellow,
                "G" => CubePerspective.Green,
                "B" => CubePerspective.Blue,
                "R" => CubePerspective.Red,
                "O" => CubePerspective.Orange,
                _ => _currentPerspective
            };

            if (targetPerspective != _currentPerspective)
            {
                _currentPerspective = targetPerspective;
                AnimateToCurrentPerspective();
            }
        }

        private void AnimateToCurrentPerspective()
        {
            if (_isAnimating) return;
            _isAnimating = true;

            // Reset scene rotation before animating camera for predictable results
            _scene.Children.Clear();
            _scene.Children.Add(new MatrixTransform3D(Matrix3D.Identity));

            // Get target camera properties
            const double camDistance = 9;
            Point3D targetPosition;
            Vector3D targetLookDirection;
            Vector3D targetUpDirection = new Vector3D(0, 1, 0); // Default

            switch (_currentPerspective)
            {
                case CubePerspective.Green: targetPosition = new Point3D(0, 0, camDistance); targetLookDirection = new Vector3D(0, 0, -1); break;
                case CubePerspective.Blue: targetPosition = new Point3D(0, 0, -camDistance); targetLookDirection = new Vector3D(0, 0, 1); break;
                case CubePerspective.Red: targetPosition = new Point3D(camDistance, 0, 0); targetLookDirection = new Vector3D(-1, 0, 0); break;
                case CubePerspective.Orange: targetPosition = new Point3D(-camDistance, 0, 0); targetLookDirection = new Vector3D(1, 0, 0); break;
                case CubePerspective.White: targetPosition = new Point3D(0, camDistance, 0); targetLookDirection = new Vector3D(0, -1, 0); targetUpDirection = new Vector3D(0, 0, -1); break;
                case CubePerspective.Yellow: targetPosition = new Point3D(0, -camDistance, 0); targetLookDirection = new Vector3D(0, 1, 0); targetUpDirection = new Vector3D(0, 0, 1); break;
                default: _isAnimating = false; return;
            }

            // Create animations
            var duration = new Duration(TimeSpan.FromMilliseconds(400));
            var ease = new CubicEase { EasingMode = EasingMode.EaseInOut };

            var posAnim = new Point3DAnimation(targetPosition, duration) { EasingFunction = ease };
            var lookAnim = new Vector3DAnimation(targetLookDirection, duration) { EasingFunction = ease };
            var upAnim = new Vector3DAnimation(targetUpDirection, duration) { EasingFunction = ease };

            posAnim.Completed += (s, e) =>
            {
                UpdateUIForPerspective();
                InitializeOrientationMap();
                _isAnimating = false;
            };

            Camera.BeginAnimation(PerspectiveCamera.PositionProperty, posAnim);
            Camera.BeginAnimation(PerspectiveCamera.LookDirectionProperty, lookAnim);
            Camera.BeginAnimation(PerspectiveCamera.UpDirectionProperty, upAnim);
        }

        private void SnapToCurrentPerspective()
        {
            _scene.Children.Clear();
            _scene.Children.Add(new MatrixTransform3D(Matrix3D.Identity));

            const double camDistance = 9;
            switch (_currentPerspective)
            {
                case CubePerspective.Green: Camera.Position = new Point3D(0, 0, camDistance); Camera.LookDirection = new Vector3D(0, 0, -1); Camera.UpDirection = new Vector3D(0, 1, 0); break;
                case CubePerspective.Blue: Camera.Position = new Point3D(0, 0, -camDistance); Camera.LookDirection = new Vector3D(0, 0, 1); Camera.UpDirection = new Vector3D(0, 1, 0); break;
                case CubePerspective.Red: Camera.Position = new Point3D(camDistance, 0, 0); Camera.LookDirection = new Vector3D(-1, 0, 0); Camera.UpDirection = new Vector3D(0, 1, 0); break;
                case CubePerspective.Orange: Camera.Position = new Point3D(-camDistance, 0, 0); Camera.LookDirection = new Vector3D(1, 0, 0); Camera.UpDirection = new Vector3D(0, 1, 0); break;
                case CubePerspective.White: Camera.Position = new Point3D(0, camDistance, 0); Camera.LookDirection = new Vector3D(0, -1, 0); Camera.UpDirection = new Vector3D(0, 0, -1); break;
                case CubePerspective.Yellow: Camera.Position = new Point3D(0, -camDistance, 0); Camera.LookDirection = new Vector3D(0, 1, 0); Camera.UpDirection = new Vector3D(0, 0, 1); break;
                default: return;
            }

            UpdateUIForPerspective();
            InitializeOrientationMap();
        }

        private void UpdateUIForPerspective()
        {
            (Brush, Brush, Brush, Brush, Brush, Brush) faceBrushes;
            switch (_currentPerspective)
            {
                case CubePerspective.Green: faceBrushes = (Brushes.White, Brushes.Yellow, Brushes.Orange, Brushes.Red, Brushes.Green, Brushes.Blue); break;
                case CubePerspective.Blue: faceBrushes = (Brushes.White, Brushes.Yellow, Brushes.Red, Brushes.Orange, Brushes.Blue, Brushes.Green); break;
                case CubePerspective.Red: faceBrushes = (Brushes.White, Brushes.Yellow, Brushes.Green, Brushes.Blue, Brushes.Red, Brushes.Orange); break;
                case CubePerspective.Orange: faceBrushes = (Brushes.White, Brushes.Yellow, Brushes.Blue, Brushes.Green, Brushes.Orange, Brushes.Red); break;
                case CubePerspective.White: faceBrushes = (Brushes.Blue, Brushes.Green, Brushes.Orange, Brushes.Red, Brushes.White, Brushes.Yellow); break;
                case CubePerspective.Yellow: faceBrushes = (Brushes.Green, Brushes.Blue, Brushes.Orange, Brushes.Red, Brushes.Yellow, Brushes.White); break;
                default: return;
            }
            (UpFace.Background, DownFace.Background, LeftFace.Background, RightFace.Background, FrontFace.Background, BackFace.Background) = faceBrushes;
        }

        private string GetMappedMove(string move)
        {
            if (string.IsNullOrEmpty(move) || !_orientationMap.ContainsKey(move[0])) return move;

            char face = move[0];
            string suffix = move.Length > 1 ? move.Substring(1) : "";
            return _orientationMap[face] + suffix;
        }

        private void InitializeOrientationMap()
        {
            _orientationMap = _currentPerspective switch
            {
                CubePerspective.Green => new Dictionary<char, char> { { 'U', 'U' }, { 'D', 'D' }, { 'L', 'L' }, { 'R', 'R' }, { 'F', 'F' }, { 'B', 'B' } },
                CubePerspective.Blue => new Dictionary<char, char> { { 'U', 'U' }, { 'D', 'D' }, { 'L', 'R' }, { 'R', 'L' }, { 'F', 'B' }, { 'B', 'F' } },
                CubePerspective.Red => new Dictionary<char, char> { { 'U', 'U' }, { 'D', 'D' }, { 'L', 'F' }, { 'R', 'B' }, { 'F', 'R' }, { 'B', 'L' } },
                CubePerspective.Orange => new Dictionary<char, char> { { 'U', 'U' }, { 'D', 'D' }, { 'L', 'B' }, { 'R', 'F' }, { 'F', 'L' }, { 'B', 'R' } },
                CubePerspective.White => new Dictionary<char, char> { { 'U', 'B' }, { 'D', 'F' }, { 'L', 'L' }, { 'R', 'R' }, { 'F', 'U' }, { 'B', 'D' } },
                CubePerspective.Yellow => new Dictionary<char, char> { { 'U', 'F' }, { 'D', 'B' }, { 'L', 'L' }, { 'R', 'R' }, { 'F', 'D' }, { 'B', 'U' } },
                _ => new Dictionary<char, char>()
            };
        }

        private void UpdateOrientationMap(string rotation)
        {
            int turns = rotation.Contains("'") ? 3 : (rotation.Contains("2") ? 2 : 1);
            for (int i = 0; i < turns; i++)
            {
                var temp = new Dictionary<char, char>(_orientationMap);
                switch (rotation[0])
                {
                    case 'x': _orientationMap['U'] = temp['F']; _orientationMap['F'] = temp['D']; _orientationMap['D'] = temp['B']; _orientationMap['B'] = temp['U']; break;
                    case 'y': _orientationMap['F'] = temp['L']; _orientationMap['R'] = temp['F']; _orientationMap['B'] = temp['R']; _orientationMap['L'] = temp['B']; break;
                    case 'z': _orientationMap['U'] = temp['R']; _orientationMap['L'] = temp['U']; _orientationMap['D'] = temp['L']; _orientationMap['R'] = temp['D']; break;
                }
            }
        }

        private void UpdateOrientationMapForRoll(bool isClockwise)
        {
            var temp = new Dictionary<char, char>(_orientationMap);
            if (isClockwise)
            {
                _orientationMap['U'] = temp['L']; _orientationMap['R'] = temp['U']; _orientationMap['D'] = temp['R']; _orientationMap['L'] = temp['D'];
            }
            else
            {
                _orientationMap['U'] = temp['R']; _orientationMap['L'] = temp['U']; _orientationMap['D'] = temp['L']; _orientationMap['R'] = temp['D'];
            }
        }
        #endregion
    }
}