﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Rubik_s_Cube
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
